local filename=tpt.input("Load machine code","Enter *.mc filename (without extension)")
local cx,cy=68,51
for cline in io.lines(filename..".mc") do
	local cid=sim.partID(cx,cy)
	if cid~=nil and sim.partProperty(cid,sim.FIELD_TYPE)==elements.DEFAULT_PT_FILT then
		sim.partProperty(cid,sim.FIELD_CTYPE,tonumber(cline,16))
	else
		tpt.log("Cannot set ctype at index "..tostring(cx-20))
	end
	cx=cx+1
end
tpt.log(filename..".mc loaded.")