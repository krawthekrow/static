#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<cstring>
#include<iostream>
using namespace std;
int RAM[512];
bool screencontent[24][24];
int regs[15];
int screen(int arg1, int arg2){
	if ((arg1 & 0x80) != 0){
		printf("Screen input (x y): ");
		int ret1, ret2;
		scanf("%d%d", &ret1, &ret2);
		return (ret2 << 5) | ret1;
	}
	else{
		for (int i = 0; i<24; i++){
			if (((arg2 >> i) & 1) == 0) screencontent[arg1][i] = false;
			else screencontent[arg1][i] = true;
		}
		system("cls");
		for (int i = 0; i<24; i++){
			for (int i2 = 0; i2<24; i2++){
				printf("%c", screencontent[i][24 - i2 - 1] ? '#' : '.');
			}
			printf("\n");
		}
		return -1;
	}
}
int display(int arg1, int arg2){
	if ((arg2 & 0x2) != 0){
		printf("Display input: ");
		int ret; scanf("%d", &ret);
		if (ret<0){
			ret = -ret;
			ret |= 0x10000000;
		}
		return ret;
	}
	else{
		int dispval = arg1;
		if ((dispval & 0x10000000) != 0){
			dispval &= 0x1FFFFFFF;
			dispval = -dispval;
		}
		printf("%x\n", dispval);
		//cin.get();
		return -1;
	}
}
int prng(int arg1, int arg2){
	return ((rand()*RAND_MAX + rand())&arg1) | arg2;
}
int sysclock(int arg1, int arg2){
	return ((time(0) % 0x20000000)&arg1) | arg2;
}
int main(){
	/*freopen("demo.mc", "w", stdout);
	printf("Hello world!\n");
	return 0;*/
	srand(time(0));
	memset(screencontent, false, sizeof(screencontent));
	char filename[100];
	printf("Enter machine code file: ");
	scanf("%s", filename);
	FILE *fin = fopen(filename, "r");
	int nextcmd;
	int cline = 0;
	memset(RAM, 0, sizeof(RAM));
	while (fscanf(fin, "%x", &RAM[cline]) != EOF){
		RAM[cline] = (RAM[cline] & 0x1FFFFFFF);
		cline++;
	}
	cline = 0;
	while (true){
		//printf("%d\n", cline);
		int nextcmd = RAM[cline]; cline++;
		int arg1 = (nextcmd & 0x0007FC00) >> 10;
		int arg2 = nextcmd & 0x000001FF;
		int cmd = (nextcmd & 0x00F00000) >> 20;
		int isreg1 = (nextcmd & 0x00080000) != 0;
		int isreg2 = (nextcmd & 0x00000200) != 0;
		int isdevcmd = (nextcmd & 0x01000000) != 0;
		int cval1 = arg1, cval2 = arg2;
		if (isreg1){
			if (arg1 >= 0 && arg1 <= 14){
				cval1 = regs[arg1];
			}
			else{
				printf("Warning: access to out of bounds register at line %d\n", cline);
				cin.get();
				cval1 = 0;
			}
		}
		else{
			if (!isdevcmd&&cmd != 0 && cmd != 3 && cmd != 14 && cmd != 15){
				printf("Warning: first argument is not a register at line %d\n", cline);
				cin.get();
			}
			if ((cval1&(0x100)) != 0){
				cval1 |= 0x1FFFFE00;
			}
		}
		if (isreg2){
			if (arg2 >= 0 && arg2 <= 14){
				cval2 = regs[arg2];
			}
			else{
				printf("Warning: access to out of bounds register at line %d\n", cline);
				cin.get();
				cval2 = 0;
			}
		}
		else{
			if ((cval2&(0x100)) != 0){
				cval2 |= 0x1FFFFE00;
			}
		}
		//printf("%d %d\n",arg1,arg2);
		if (isdevcmd){
			int res = -1;
			if (cmd == 0) res = screen(cval1, cval2);
			else if (cmd == 1) res = display(cval1, cval2);
			else if (cmd == 2) res = prng(cval1, cval2);
			else if (cmd == 3) res = sysclock(cval1, cval2);
			else{
				printf("Warning: access to out of bounds device port at line %d\n", cline);
				cin.get();
			}
			if (res != -1){
				regs[14] = (res&0x1FFFFFFF);
			}
		}
		else{
			if (cmd == 0) break;
			else if (cmd == 1) regs[arg1] = cval2;
			else if (cmd == 2) regs[arg1] = RAM[cval2 & 0x1FF];
			else if (cmd == 3) RAM[cval1 & 0x1FF] = cval2;
			else if (cmd == 4) regs[arg1] &= cval2;
			else if (cmd == 5) regs[arg1] |= cval2;
			else if (cmd == 6) regs[arg1] ^= cval2;
			else if (cmd == 7) regs[arg1] = ((~regs[arg1])&cval2);
			else if (cmd == 8) regs[arg1] = ((regs[arg1] << cval2) & 0x1FFFFFFF);
			else if (cmd == 9) regs[arg1] = (regs[arg1] >> cval2);
			else if (cmd == 10) regs[arg1] = ((regs[arg1] + 1) & 0x1FFFFFFF);
			else if (cmd == 11) regs[arg1] = ((regs[arg1] - 1) & 0x1FFFFFFF);
			else if (cmd == 12) regs[arg1] = ((regs[arg1] + cval2) & 0x1FFFFFFF);
			else if (cmd == 13) regs[arg1] = ((regs[arg1] - cval2) & 0x1FFFFFFF);
			else if (cmd == 14){
				if (cval1 != 0) cline = (cval2&0x1FF);
			}
			else if (cmd == 15){
				if ((cval1&(0x10000000)) != 0) cline = (cval2 & 0x1FF);
			}
			else{
				printf("Should not print.\n");
				cin.get();
			}
		}
	}
	system("pause");
	return 0;
}
