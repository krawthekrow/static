--Assigns the ctype of many filter particles in a row.
local sx,sy,cval=560,304,0
for i=0,14 do
	cx=sx+i*2
	cy=sy
	local cid=sim.partID(cx,cy)
	if cid~=nil and sim.partProperty(cid,sim.FIELD_TYPE)==elements.DEFAULT_PT_FILT then
		sim.partProperty(cid,sim.FIELD_CTYPE,bit.lshift(i,10)+tonumber("20000000",16))
	else
		tpt.log("Cannot set ctype at point "..tostring(cx)..", "..tostring(cy))
	end
end
tpt.log("ctype assigned.")